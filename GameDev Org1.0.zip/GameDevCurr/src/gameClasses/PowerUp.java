package gameClasses;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import gameClasses.Player;

public class PowerUp extends Rectangle
{
	private static final long serialVersionUID = 1L;
	private int x, y;
	private final int SIZE = 40;
	
	public PowerUp()
	{
		x = 800;
		y = 300;
	}
	
	public void drawPowerUp(Graphics g)
	{
		g.setColor(Color.YELLOW);
		g.fillRect(x, y, SIZE, SIZE);
	}
	
	public void move()
	{
		if(x > -100)
			x -= 20;
	}
	
	public int getX()
	{
		return x;
	}
	
	public void setX(int newX)
	{
		x = newX;
	}
	
	public 

	
	public boolean intersects(Player player) 
	{
		int tw = SIZE;
		int th = SIZE;
		int rw = player.size;
		int rh = player.size;
		if (rw <= 0 || rh <= 0 || tw <= 0 || th <= 0) 
		{
			return false;
		}
		int tx = x;
		int ty = y;
		int rx = player.getX();
		int ry = player.getY();
		rw += rx;
		rh += ry;
		tw += tx;
		th += ty;
		//      overflow || intersect
		return ((rw < rx || rw > tx) &&
				(rh < ry || rh > ty) &&
				(tw < tx || tw > rx) &&
				(th < ty || th > ry));
		}
}
