package Classes;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.geom.Area;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JComponent;

public class Obj extends JComponent
{ 
	private static final long serialVersionUID = 1L;

	private Rectangle hitBox;
	public Area area;
	int x, y, height, width;
	public static ArrayList<Obj> objList = new ArrayList<Obj>();

	private Random rand = new Random();
	
	//public static Obj object = new Obj();

	
	public Obj(int x, int y)
	{
		this.x = x;
		this.y = y;
		height = 50 + rand.nextInt(20);
		width = 50;
		hitBox = new Rectangle(x, y, width, height);
		area = new Area(hitBox);
	}
	
	/*public void draw1(Graphics g)
	{
		g.setColor(Color.RED);
		width = 60;
		g.fillRect(x, y - 30, width, 80);
		g.fillRect(x, y, width, height);
	}
	
	public void draw2(Graphics g)
	{
		g.setColor(Color.RED);
		g.fillRect(x, y - 50, width, 100);
	}*/
	
	public static void draw(Graphics g, ArrayList<Obj> objList)
	{
		for(Obj object: objList)
		{
			drawObj(g, object);
		}
	}
	
	public static void drawObj(Graphics g, Obj object)
	{
		g.setColor(Color.RED);
		g.fillRect(object.getX(), object.getY(), object.getWidth(), object.getHeight());
	}
	
	public static void addObj()
	{
		//int space = 400;
		objList.add(new Obj(800, 400));

	}
	
	public static void move(ArrayList<Obj> arr)
	{
		for(int i = 0; i < arr.size(); i++)
		{
			int x = arr.get(i).getX();
			if(x >= 200)
				arr.get(i).setX(x -= 20);
			else if(x <= 0)
			{
				arr.remove(i);
				addObj();
			}
		}
	}
	
	public int getY()
	{
		return y;
	}
	
	public int getX()
	{
		return x;
	}
	
	public void setY(int y)
	{
		this.y = y;
	}
	
	public void setX(int x)
	{
		this.x = x;
	}
	
	public void update()
	{
		
	}
}
