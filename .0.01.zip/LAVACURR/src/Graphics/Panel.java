package Graphics;

import java.awt.Graphics;
import java.util.ArrayList;
import javax.swing.JPanel;

import Classes.Cloud;
import Classes.Obj;
import Classes.Player;
import Classes.World;

public class Panel extends JPanel
{
	private static final long serialVersionUID = 1L;
	public Player player;
	private Cloud cloud;
	private World world = new World();
	private static ArrayList<Obj> objList;
	
	
	public Panel()
	{
		player = Player.player;
		setObjList(Obj.objList);
		setCloud(Cloud.cloud);
		this.setVisible(true);
		Obj.addObj();
		Obj.addObj();
	}
	
	public void addPlayer(Player player)
	{
		this.player = player;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void addObject(ArrayList object)
	{
		Panel.setObjList(object);
	}
	
	public void addCloud(Cloud cloud)
	{
		this.setCloud(cloud);
	}
	
	@Override
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		world.draw(g);
		player.draw(g);
		cloud.draw(g);
		Obj.draw(g, objList);
	}
	
	public void update()
	{
		revalidate();
		repaint();
	}

	public Cloud getCloud() {
		return cloud;
	}

	public void setCloud(Cloud cloud) {
		this.cloud = cloud;
	}
	
	public static boolean isColiding()
	{
		boolean test = false;
		for(int i = 0; i < getObjList().size(); i++)
		{
			Obj object = getObjList().get(i);
			if(Player.area.intersects(object.getX(), object.getY(), 50, 50))
				test = true;
		}
		return test;
	}

	public static ArrayList<Obj> getObjList() 
	{
		return objList;
	}

	public static void setObjList(ArrayList<Obj> objList) 
	{
		Panel.objList = objList;
	}
}
