package game;


import java.awt.Color;
import java.awt.Graphics;
import java.sql.Driver;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.KeyStroke;

import gameClasses.Player;

public class Panel extends JPanel
{
	private static final long serialVersionUID = 1L;
	
	public Panel()
	{
		setVisible(true);	
	}  
	
	/*@Override
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.setColor(gameClasses.Driver.c);
		player.drawChar(g);
	}*/
}
