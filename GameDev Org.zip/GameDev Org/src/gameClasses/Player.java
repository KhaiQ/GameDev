package gameClasses;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JComponent;
import gameClasses.Game;

public class Player extends JComponent implements game.Character
{
	
	private int x , y ;
	
	public int size;
	
	private int gravity = 10;
	
	private int yMotion;
	
	private static Player player = new Player(20);
	
	public Player(int s)
	{
		x = 100;
		y = 400;
		size = s;
	}
	
	public static Player getPlayer() 
	{
		return player;
	}
	
	public void setPlayer(Player player) 
	{
		this.player = player;
	}
	
	public int getY()
	{
		return y;
	}
	
	public int getX()
	{
		return x;
	}
	
	public void setY(int y)
	{
		this.y = y;
	}
	
	public void setX(int x)
	{
		this.x = x;
	}
	
	public int getSize()
	{
		return size;
		
	}
	
	public void setSize(int s)
	{
		size = s;
	}
	
	public void drawChar(Graphics g)
	{
		super.paintComponent(g);
		g.fillOval(x, y, size, size);
	}
	
	/*public void Update(Game g)
	{
		g.repaint();
	}*/
	
	/*public void fall()
	{
		if(y<400)
		{
			y+=60;
		}
	}*/
	
	public void repaint(Graphics g)
	{
		g.fillOval(x, y, size, size);
	}
	
	public void fall()
	{
		if(y < 400)
		{
			if(yMotion < 15)
				yMotion += 3;
		}
		y += yMotion;			
		if(y > 400)
			y = 400;
	}
	
	public void jump()
	{
		if(yMotion > 0)
			yMotion = 0;
		yMotion = -30;
	}
	
}
