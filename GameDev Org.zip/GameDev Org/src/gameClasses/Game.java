package gameClasses;


import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.swing.JFrame;

import javax.swing.JFrame;

import game.Panel;
import gameClasses.Player;

public class Game extends JFrame implements game.Game,MouseListener, MouseMotionListener,KeyListener
{
	private static final long serialVersionUID = 1L;
	
	private JFrame jframe; 
	
	private static boolean gameOver = false;
	
	private Renderer renderer;
	
	public Game(int w , int h)
	{	
		jframe = new JFrame();
		renderer = new Renderer();
		
		jframe.add(renderer);
		jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jframe.setSize(w, h);	
		jframe.addMouseMotionListener(this);
		jframe.addMouseListener((MouseListener) this);
		//setLayout(new GridLayout(1,1));
		jframe.setResizable(false);
		jframe.setTitle("The Floor is Hot");
		jframe.setVisible(true);

	}
	
	public Renderer getRenderer()
	{
		return renderer;
	}

	public static boolean getGameOver()
	{
		return gameOver;
	}
	
	public static void setGameOver(boolean d)
	{
		gameOver = d;
	}
	
	@Override
	public void mouseDragged(MouseEvent e)
	{
		/*if(e.getX()>100)
		{
			panel.getPlayer().size += 10;
		}
		if(e.getX() < 100)
		{
			panel.getPlayer().size -= 10;
		}*/
	}

	@Override
	public void mouseMoved(MouseEvent e) 
	{
		//panel.getPlayer().setX(e.getX());
		
		
	}

	@Override
	public void mouseClicked(MouseEvent e)
	{
		while(!gameOver)
		{
			int yPos = Player.getPlayer().getY();
			if(yPos >= 400)
				Player.getPlayer().jump();
		}
	}

	@Override
	public void mousePressed(MouseEvent e) 
	{
		int yPos = Player.getPlayer().getY();
		if(yPos >= 400)
			Player.getPlayer().jump();
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) 
	{
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
}
