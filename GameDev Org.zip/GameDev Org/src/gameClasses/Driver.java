package gameClasses;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import gameClasses.Player;
import gameClasses.Renderer;
import gameClasses.Game;
public class Driver
{
	public static Color c;
	static Game game = new Game(800,800);

	public static void main(String[] args)
	{
		while(true)
		{
			game.repaint();
			Player.getPlayer().repaint();
			game.getRenderer().repaint();
			c = new Color((int) (Math.random()*255),(int) (Math.random()*255),(int) (Math.random()*255));
			gameClasses.Player.getPlayer().fall();
			//wait---
			try{Thread.sleep(50);}catch(Exception e){}
		}
	}
}
