package Classes;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Rectangle;

import javax.swing.JComponent;

public class Player extends JComponent
{
	
	private static final long serialVersionUID = 1L;
	
	private int x, y;
	private int yMotion;
	
	private int powerUp;
	private int size;
	
	public Player(int s)
	{
		setX(100);
		setSize(s);
	}
	
	public void draw(Graphics g)
	{
		super.paintComponent(g);
		g.fillRect(x, y, size, size);
	}
	
	public void jump()
	{
		
	}
	
	public void update()
	{
		
	}

	public int getX() 
	{
		return x;
	}

	public void setX(int x) 
	{
		this.x = x;
	}

	public int getY() 
	{
		return y;
	}

	public void setY(int y) 
	{
		this.y = y;
	}

	public int getyMotion() 
	{
		return yMotion;
	}

	public void setyMotion(int yMotion) 
	{
		this.yMotion = yMotion;
	}

	public int getPowerUp() 
	{
		return powerUp;
	}

	public void setPowerUp(int powerUp) 
	{
		this.powerUp = powerUp;
	}

	public int getSize() 
	{
		return size;
	}

	public void setSize(int size) 
	{
		this.size = size;
	}
}
